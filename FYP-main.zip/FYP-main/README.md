# FYP
This is a project to help Chris to do his FYP

# prestudy
This allows users to sign the document

# during_study_1
This uses a code to ensure people read the passage
